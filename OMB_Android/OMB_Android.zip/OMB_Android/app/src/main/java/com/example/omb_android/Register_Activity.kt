package com.example.omb_android

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class Register_Activity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register_)

    }

}
